# Privacy Policy    

### SMS Permission    

* **SMS permission** is only used for **Post-Copy Action**.   
* We **don't** collect any sms data and upload it. (Also not **Internet** permission :)    

### Nevolution   
* See https://play.google.com/store/apps/details?id=com.oasisfeng.nevo

