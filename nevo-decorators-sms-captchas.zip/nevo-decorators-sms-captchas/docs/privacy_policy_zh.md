# 隐私政策   

### 短信权限   

* **短信权限** 仅仅用于 **复制后操作** 功能.   
* 我们 **不会** 收集任何短信数据并上传  (也没有 **完全的网络访问** 权限 :)    

### Nevolution   
* 参见 https://play.google.com/store/apps/details?id=com.oasisfeng.nevo
 
