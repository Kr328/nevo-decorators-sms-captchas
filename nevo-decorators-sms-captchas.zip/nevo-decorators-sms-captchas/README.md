# Sms Captchas Decorator for Nevolution       
Download prebuilt package from [Google Play](https://play.google.com/store/apps/details?id=me.kr328.nevo.decorators.smscaptcha) or [Github releases](https://github.com/Kr328/nevo-decorators-sms-captcha/releases)

## Introduction
Enhance short message captcha notification with following features:
- Direct copy captcha on notificaton.
- Hide captcha on lockscreen.

## Requirements    
 - Android 7.0 +
 - [Nevolution](https://play.google.com/store/apps/details?id=com.oasisfeng.nevo) installed
 - AOSP based ROM

## Thanks
 - Icon - [fython](https://github.com/fython) 

## License
GPLv3
